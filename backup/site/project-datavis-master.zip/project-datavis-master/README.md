# Presentation Letter #
Este é o projeto final da disciplina de visualização de dados 2017.2.

# Team #
- Maurício Moreira Neto
- Francisco Anderson de Almada Gomes
- Elias Barroso

# Project Description #

Doing!
